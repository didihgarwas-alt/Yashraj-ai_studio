import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname,"public")));

function needKey(res){
  if(!process.env.OPENAI_API_KEY){
    res.status(500).json({error:"OPENAI_API_KEY is missing. Add it to .env on the server."});
    return false;
  }
  return true;
}

app.post("/api/story", async (req,res)=>{
  if(!needKey(res)) return;
  try{
    const idea=String(req.body.idea||"").trim();
    if(!idea) return res.status(400).json({error:"Enter a story idea."});
    const r=await client.responses.create({
      model:"gpt-5-mini",
      input:`Create a YouTube Shorts story from this idea: ${idea}.
Return: title, 10-12 scene list, each scene 4-8 seconds, visual prompt, on-screen text, and sound effect. Keep characters visually consistent.`
    });
    res.json({text:r.output_text});
  }catch(e){res.status(500).json({error:e.message||"Story generation failed."});}
});

app.post("/api/image", async (req,res)=>{
  if(!needKey(res)) return;
  try{
    const prompt=String(req.body.prompt||"").trim();
    if(!prompt) return res.status(400).json({error:"Enter an image prompt."});
    const r=await client.images.generate({
      model:"gpt-image-1-mini",
      prompt,
      size:"1024x1024"
    });
    res.json({image:`data:image/png;base64,${r.data[0].b64_json}`});
  }catch(e){res.status(500).json({error:e.message||"Image generation failed."});}
});

app.post("/api/video", async (req,res)=>{
  if(!needKey(res)) return;
  try{
    const prompt=String(req.body.prompt||"").trim();
    if(!prompt) return res.status(400).json({error:"Enter a video prompt."});
    const form=new FormData();
    form.append("model","sora-2");
    form.append("prompt",prompt);
    form.append("seconds",String(req.body.seconds||"4"));
    form.append("size","720x1280");
    const r=await fetch("https://api.openai.com/v1/videos",{
      method:"POST",
      headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},
      body:form
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||"Video request failed."});
    res.json({job:data});
  }catch(e){res.status(500).json({error:e.message||"Video generation failed."});}
});

app.get("/api/video/:id", async (req,res)=>{
  if(!needKey(res)) return;
  try{
    const r=await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(req.params.id)}`,{
      headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||"Status request failed."});
    res.json({job:data});
  }catch(e){res.status(500).json({error:e.message||"Status check failed."});}
});

app.get("/api/video/:id/content", async (req,res)=>{
  if(!needKey(res)) return;
  try{
    const r=await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(req.params.id)}/content`,{
      headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}
    });
    if(!r.ok){
      const t=await r.text();
      return res.status(r.status).send(t);
    }
    res.setHeader("Content-Type","video/mp4");
    const buf=Buffer.from(await r.arrayBuffer());
    res.send(buf);
  }catch(e){res.status(500).json({error:e.message||"Download failed."});}
});

app.listen(port,()=>console.log(`Yashraj AI Studio: http://localhost:${port}`));
